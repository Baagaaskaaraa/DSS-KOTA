# visualizer.py
# UPGRADE: Gambar lebih besar, label lebih jelas, multi-segment warna berbeda

import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from core.graph import GRAPH, NODE_TYPES, get_all_edges


NODE_COLORS = {
    "depot" : "#E63946",
    "hub"   : "#457B9D",
    "zone"  : "#2A9D8F",
}

EDGE_COLOR_DEFAULT = "#4A5568"

SEGMENT_COLORS = [
    "#F4A261",  # oranye
    "#E9C46A",  # kuning
    "#A8DADC",  # biru muda
    "#B5838D",  # pink
    "#81B29A",  # sage
    "#F2CC8F",  # krem
]


def build_nx_graph():
    G = nx.Graph()
    for node in NODE_TYPES:
        G.add_node(node, node_type=NODE_TYPES[node])
    for a, b, w in get_all_edges():
        G.add_edge(a, b, weight=w)
    return G


def get_node_color_list(G):
    return [NODE_COLORS[NODE_TYPES[n]] for n in G.nodes()]


def get_layout(G):
    pos = {
        "Central Depot" : (0,    0),
        "Hub Nexus"     : (-3,   2),
        "Hub Vertex"    : ( 3,   2),
        "Hub Orbit"     : (-3,  -2),
        "Hub Apex"      : ( 3,  -2),
        "Zone Altair"   : (-5.5, 4),
        "Zone Bravo"    : (-2,   4.5),
        "Zone Crest"    : ( 2,   4.5),
        "Zone Delta"    : ( 5.5, 4),
        "Zone Echo"     : (-5.5,-4),
        "Zone Faro"     : (-1.5,-4.5),
        "Zone Grid"     : ( 2,  -4.5),
        "Zone Haven"    : ( 5.5,-4),
    }
    return pos


def draw_graph(path=None, segments=None, title="Kota Syntara — Jaringan Distribusi"):
    G   = build_nx_graph()
    pos = get_layout(G)

    # Ukuran lebih besar + DPI tinggi
    fig, ax = plt.subplots(figsize=(22, 14), dpi=130)
    fig.patch.set_facecolor("#0A1520")
    ax.set_facecolor("#0A1520")

    # -----------------------------------------------------------
    # Bangun peta edge → warna & lebar
    # -----------------------------------------------------------
    edge_color_map = {}
    edge_width_map = {}
    all_path_nodes = set()
    segment_stop_nodes = []   # titik awal/akhir tiap segmen

    if segments:
        for seg_idx, seg_path in enumerate(segments):
            color = SEGMENT_COLORS[seg_idx % len(SEGMENT_COLORS)]
            if len(seg_path) > 1:
                for i in range(len(seg_path) - 1):
                    u, v = seg_path[i], seg_path[i + 1]
                    key = tuple(sorted([u, v]))
                    edge_color_map[key] = color
                    edge_width_map[key] = 5.5
                all_path_nodes.update(seg_path)
                segment_stop_nodes.append(seg_path[0])
                segment_stop_nodes.append(seg_path[-1])

    elif path and len(path) > 1:
        color = SEGMENT_COLORS[0]
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            key = tuple(sorted([u, v]))
            edge_color_map[key] = color
            edge_width_map[key] = 5.5
        all_path_nodes.update(path)
        if path:
            segment_stop_nodes = [path[0], path[-1]]

    # -----------------------------------------------------------
    # Gambar edge dengan glow effect (layer berlapis)
    # -----------------------------------------------------------
    # Layer 1: glow untuk path edges
    glow_edges  = [(u,v) for u,v in G.edges() if tuple(sorted([u,v])) in edge_color_map]
    glow_colors = [edge_color_map[tuple(sorted([u,v]))] for u,v in glow_edges]
    if glow_edges:
        nx.draw_networkx_edges(G, pos, edgelist=glow_edges,
            edge_color=glow_colors, width=12, ax=ax, alpha=0.15)
        nx.draw_networkx_edges(G, pos, edgelist=glow_edges,
            edge_color=glow_colors, width=7, ax=ax, alpha=0.3)

    # Layer 2: semua edge
    all_edge_colors = []
    all_edge_widths = []
    for u, v in G.edges():
        key = tuple(sorted([u, v]))
        if key in edge_color_map:
            all_edge_colors.append(edge_color_map[key])
            all_edge_widths.append(5.5)
        else:
            all_edge_colors.append(EDGE_COLOR_DEFAULT)
            all_edge_widths.append(1.2)

    nx.draw_networkx_edges(
        G, pos,
        edge_color=all_edge_colors,
        width=all_edge_widths,
        ax=ax, alpha=0.9,
    )

    # -----------------------------------------------------------
    # Gambar node — glow untuk node di jalur
    # -----------------------------------------------------------
    if all_path_nodes:
        # Glow layer
        nx.draw_networkx_nodes(G, pos,
            nodelist=list(all_path_nodes),
            node_color="#F4A261",
            node_size=3000, ax=ax, alpha=0.15)
        nx.draw_networkx_nodes(G, pos,
            nodelist=list(all_path_nodes),
            node_color="#F4A261",
            node_size=2200, ax=ax, alpha=0.25)

    # Base node layer
    nx.draw_networkx_nodes(
        G, pos,
        node_color=get_node_color_list(G),
        node_size=1800,
        ax=ax,
        linewidths=1.5,
        edgecolors="#2E4057",
    )

    # Highlight node di jalur (warna aslinya, tapi border putih)
    if all_path_nodes:
        highlight_colors = [NODE_COLORS[NODE_TYPES[n]] for n in all_path_nodes]
        nx.draw_networkx_nodes(G, pos,
            nodelist=list(all_path_nodes),
            node_color=highlight_colors,
            node_size=2000, ax=ax,
            linewidths=2.5,
            edgecolors="#FFFFFF")

    # Titik start/end tiap segmen: lebih besar + border tebal
    if segment_stop_nodes:
        unique_stops = list(set(segment_stop_nodes))
        stop_colors = [NODE_COLORS[NODE_TYPES[n]] for n in unique_stops]
        nx.draw_networkx_nodes(G, pos,
            nodelist=unique_stops,
            node_color=stop_colors,
            node_size=2400, ax=ax,
            linewidths=3.5,
            edgecolors="#F4A261")

    # -----------------------------------------------------------
    # Label node — lebih besar dan jelas
    # -----------------------------------------------------------
    nx.draw_networkx_labels(
        G, pos,
        font_size=10,
        font_color="white",
        font_weight="bold",
        ax=ax,
    )

    # -----------------------------------------------------------
    # Label bobot edge — lebih jelas
    # -----------------------------------------------------------
    edge_labels = nx.get_edge_attributes(G, "weight")
    edge_label_formatted = {k: f"{v} km" for k, v in edge_labels.items()}
    nx.draw_networkx_edge_labels(
        G, pos,
        edge_labels=edge_label_formatted,
        font_size=9,
        font_color="#E0E6ED",
        bbox=dict(boxstyle="round,pad=0.3", fc="#1E2D3D", ec="#2E4057", alpha=0.85),
        ax=ax,
    )

    # -----------------------------------------------------------
    # Legend
    # -----------------------------------------------------------
    legend_items = [
        mpatches.Patch(color=NODE_COLORS["depot"], label="Gudang Pusat"),
        mpatches.Patch(color=NODE_COLORS["hub"],   label="Hub Transit"),
        mpatches.Patch(color=NODE_COLORS["zone"],  label="Drop Point"),
    ]

    if segments:
        for i, seg in enumerate(segments):
            if len(seg) >= 2:
                color = SEGMENT_COLORS[i % len(SEGMENT_COLORS)]
                label = f"Seg {i+1}: {seg[0]} → {seg[-1]}"
                legend_items.append(mpatches.Patch(color=color, label=label))
    elif path:
        legend_items.append(
            mpatches.Patch(color=SEGMENT_COLORS[0], label="Rute Terpendek")
        )

    legend = ax.legend(
        handles=legend_items,
        loc="upper right",
        facecolor="#1E2D3D",
        edgecolor="#F4A261",
        labelcolor="white",
        fontsize=10,
        framealpha=0.95,
        borderpad=0.8,
    )
    legend.get_frame().set_linewidth(1.5)

    ax.set_title(title, color="white", fontsize=16, pad=22, fontweight="bold")
    ax.axis("off")
    plt.tight_layout(pad=2.0)

    return fig
