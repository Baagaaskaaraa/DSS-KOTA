# graph.py
# Struktur data utama: representasi graph Kota Syntara
# Menggunakan Adjacency List (dictionary) dengan bobot jarak (km)

# -----------------------------------------------------------
# TIPE NODE
# Setiap node punya tipe: "depot", "hub", atau "zone"
# Ini dipakai nanti untuk pewarnaan di visualisasi
# -----------------------------------------------------------

NODE_TYPES = {
    "Central Depot" : "depot",
    "Hub Nexus"     : "hub",
    "Hub Vertex"    : "hub",
    "Hub Orbit"     : "hub",
    "Hub Apex"      : "hub",
    "Zone Altair"   : "zone",
    "Zone Bravo"    : "zone",
    "Zone Crest"    : "zone",
    "Zone Delta"    : "zone",
    "Zone Echo"     : "zone",
    "Zone Faro"     : "zone",
    "Zone Grid"     : "zone",
    "Zone Haven"    : "zone",
}

# -----------------------------------------------------------
# ADJACENCY LIST
# Format: { "NodeA": {"NodeB": jarak, "NodeC": jarak}, ... }
# Graph ini UNDIRECTED — kalau A ke B bisa, maka B ke A juga bisa
# -----------------------------------------------------------

GRAPH = {
    "Central Depot": {
        "Hub Nexus"  : 5,
        "Hub Vertex" : 7,
        "Hub Orbit"  : 6,
        "Hub Apex"   : 8,
    },
    "Hub Nexus": {
        "Central Depot" : 5,
        "Hub Vertex"    : 3,
        "Zone Altair"   : 4,
        "Zone Bravo"    : 5,
        "Zone Grid"     : 8,
    },
    "Hub Vertex": {
        "Central Depot" : 7,
        "Hub Nexus"     : 3,
        "Zone Crest"    : 3,
        "Zone Delta"    : 6,
        "Zone Faro"     : 7,
    },
    "Hub Orbit": {
        "Central Depot" : 6,
        "Hub Apex"      : 4,
        "Zone Echo"     : 4,
        "Zone Faro"     : 5,
    },
    "Hub Apex": {
        "Central Depot" : 8,
        "Hub Orbit"     : 4,
        "Zone Grid"     : 3,
        "Zone Haven"    : 4,
    },
    "Zone Altair" : {"Hub Nexus"  : 4},
    "Zone Bravo"  : {"Hub Nexus"  : 5},
    "Zone Crest"  : {"Hub Vertex" : 3},
    "Zone Delta"  : {"Hub Vertex" : 6},
    "Zone Echo"   : {"Hub Orbit"  : 4},
    "Zone Faro"   : {"Hub Orbit"  : 5, "Hub Vertex": 7},
    "Zone Grid"   : {"Hub Apex"   : 3, "Hub Nexus" : 8},
    "Zone Haven"  : {"Hub Apex"   : 4},
}


def get_all_nodes():
    return list(NODE_TYPES.keys())


def get_all_edges():
    edges = []
    visited = set()
    for node, neighbors in GRAPH.items():
        for neighbor, weight in neighbors.items():
            pair = tuple(sorted([node, neighbor]))
            if pair not in visited:
                edges.append((node, neighbor, weight))
                visited.add(pair)
    return edges


def get_neighbors(node):
    return GRAPH.get(node, {})
