# app.py
# Antarmuka utama DSS Rute Pengiriman Paket — Kota Syntara
# UPGRADE: Multi-tujuan + Visualisasi lebih besar
# Jalankan dengan: streamlit run app.py

import streamlit as st
import matplotlib
matplotlib.use("Agg")

from core.graph import get_all_nodes, NODE_TYPES
from core.dijkstra import dijkstra, get_step_by_step
from core.visualizer import draw_graph

# -----------------------------------------------------------
# KONFIGURASI HALAMAN
# -----------------------------------------------------------

st.set_page_config(
    page_title="DSS Rute Pengiriman — Kota Syntara",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -----------------------------------------------------------
# CSS KUSTOM
# -----------------------------------------------------------

st.markdown("""
<style>
    .stApp { background-color: #0F1923; color: #E0E6ED; }
    [data-testid="stSidebar"] { background-color: #1E2D3D; border-right: 1px solid #2E4057; }
    [data-testid="stSidebar"] * { color: #E0E6ED !important; }
    .sidebar-title { font-size: 1.1rem; font-weight: 700; color: #F4A261 !important;
        margin-bottom: 0.3rem; letter-spacing: 0.04em; text-transform: uppercase; }
    .result-card { background-color: #1E2D3D; border: 1px solid #2E4057;
        border-left: 4px solid #F4A261; border-radius: 8px;
        padding: 1.2rem 1.5rem; margin-bottom: 1rem; }
    .segment-card { background-color: #162330; border: 1px solid #2E4057;
        border-radius: 8px; padding: 1rem 1.2rem; margin-bottom: 0.8rem; }
    .step-item { background-color: #162330; border: 1px solid #2E4057;
        border-radius: 6px; padding: 0.6rem 1rem; margin-bottom: 0.4rem;
        font-size: 0.9rem; color: #C8D6E5; }
    .step-arrow { color: #F4A261; font-weight: bold; }
    .badge-depot { background-color: #E63946; color: white; padding: 2px 8px;
        border-radius: 12px; font-size: 0.72rem; font-weight: 600; }
    .badge-hub { background-color: #457B9D; color: white; padding: 2px 8px;
        border-radius: 12px; font-size: 0.72rem; font-weight: 600; }
    .badge-zone { background-color: #2A9D8F; color: white; padding: 2px 8px;
        border-radius: 12px; font-size: 0.72rem; font-weight: 600; }
    .distance-display { font-size: 2.4rem; font-weight: 800; color: #F4A261; line-height: 1.1; }
    .distance-label { font-size: 0.85rem; color: #7F8C9A; letter-spacing: 0.08em; text-transform: uppercase; }
    .main-header { font-size: 1.6rem; font-weight: 800; color: #F4A261; letter-spacing: 0.02em; }
    .main-subtitle { font-size: 0.9rem; color: #7F8C9A; margin-top: -0.5rem; margin-bottom: 1.2rem; }
    .stop-tag { display: inline-block; background-color: #1E2D3D; border: 1px solid #F4A261;
        color: #F4A261; border-radius: 20px; padding: 3px 12px; font-size: 0.82rem;
        margin: 2px; font-weight: 600; }
    .total-bar { background: linear-gradient(90deg, #F4A261, #E07A3A);
        border-radius: 6px; padding: 0.8rem 1.2rem; margin-bottom: 1rem; }
    hr { border-color: #2E4057 !important; }
    .stSelectbox label, .stRadio label { color: #B0BEC5 !important; font-size: 0.85rem !important; }
    .stButton > button { background-color: #F4A261; color: #0F1923; font-weight: 700;
        border: none; border-radius: 6px; padding: 0.55rem 1.2rem;
        width: 100%; font-size: 0.95rem; transition: background 0.2s; }
    .stButton > button:hover { background-color: #E07A3A; color: #0F1923; }
    div[data-testid="stImage"] img { border-radius: 10px; }
</style>
""", unsafe_allow_html=True)


# -----------------------------------------------------------
# HELPER
# -----------------------------------------------------------

def node_badge(node_name):
    t = NODE_TYPES.get(node_name, "zone")
    label = {"depot": "Gudang Pusat", "hub": "Hub Transit", "zone": "Drop Point"}.get(t, t)
    return f'<span class="badge-{t}">{label}</span>'

SEGMENT_COLORS_HEX = ["#F4A261","#E9C46A","#A8DADC","#B5838D","#81B29A","#F2CC8F"]


# -----------------------------------------------------------
# SESSION STATE INIT
# -----------------------------------------------------------

if "stops" not in st.session_state:
    all_n = get_all_nodes()
    st.session_state.stops = [all_n[0], all_n[-1]]   # default: 2 titik

if "last_result" not in st.session_state:
    st.session_state.last_result = None


# -----------------------------------------------------------
# SIDEBAR
# -----------------------------------------------------------

with st.sidebar:
    st.markdown('<div class="sidebar-title">📦 Kota Syntara</div>', unsafe_allow_html=True)
    st.markdown("**Decision Support System**  \nRute Pengiriman Multi-Tujuan", unsafe_allow_html=False)
    st.divider()

    all_nodes = get_all_nodes()

    st.markdown("**📍 Daftar Titik Perjalanan**")
    st.caption("Urutan dari atas = urutan perjalanan")

    # Tampilkan setiap titik stop
    stops_to_remove = None
    for i, stop in enumerate(st.session_state.stops):
        col_sel, col_del = st.columns([4, 1])
        with col_sel:
            label_icon = "🏭" if i == 0 else ("🏁" if i == len(st.session_state.stops)-1 else f"📌 #{i}")
            new_val = st.selectbox(
                label=f"{label_icon} Titik {i+1}",
                options=all_nodes,
                index=all_nodes.index(stop) if stop in all_nodes else 0,
                key=f"stop_{i}",
                label_visibility="visible",
            )
            st.session_state.stops[i] = new_val
        with col_del:
            st.markdown("<br>", unsafe_allow_html=True)
            if len(st.session_state.stops) > 2:
                if st.button("✕", key=f"del_{i}", help="Hapus titik ini"):
                    stops_to_remove = i

        st.markdown(node_badge(st.session_state.stops[i]), unsafe_allow_html=True)
        st.markdown("")

    if stops_to_remove is not None:
        st.session_state.stops.pop(stops_to_remove)
        st.rerun()

    # Tombol tambah titik
    col_add1, col_add2 = st.columns(2)
    with col_add1:
        if st.button("➕ Tambah Titik"):
            # Default tambah node yang belum ada
            remaining = [n for n in all_nodes if n not in st.session_state.stops]
            new_node = remaining[0] if remaining else all_nodes[0]
            st.session_state.stops.append(new_node)
            st.rerun()
    with col_add2:
        if st.button("🔄 Reset"):
            st.session_state.stops = [all_nodes[0], all_nodes[-1]]
            st.session_state.last_result = None
            st.rerun()

    st.divider()
    cari_button = st.button("🔍 Hitung Rute Terpendek", key="cari")

    st.divider()
    st.markdown("**Legenda**")
    st.markdown(
        '<span class="badge-depot">Gudang Pusat</span>&nbsp; Distribusi utama<br><br>'
        '<span class="badge-hub">Hub Transit</span>&nbsp; Titik perantara<br><br>'
        '<span class="badge-zone">Drop Point</span>&nbsp; Pengiriman akhir',
        unsafe_allow_html=True,
    )


# -----------------------------------------------------------
# MAIN CONTENT
# -----------------------------------------------------------

st.markdown('<div class="main-header">🗺️ DSS Rute Pengiriman — Kota Syntara</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="main-subtitle">Sistem Penentuan Rute Terpendek Multi-Tujuan berbasis Algoritma Dijkstra</div>',
    unsafe_allow_html=True,
)

# Tampilkan rute yang dipilih saat ini
stops_display = " → ".join([f'<span class="stop-tag">{s}</span>' for s in st.session_state.stops])
st.markdown(f"**Rute yang dipilih:** {stops_display}", unsafe_allow_html=True)
st.markdown("")


# -----------------------------------------------------------
# PROSES PENCARIAN MULTI-TUJUAN
# -----------------------------------------------------------

if cari_button:
    stops = st.session_state.stops
    errors = []

    # Validasi: tidak ada yang sama berurutan
    for i in range(len(stops) - 1):
        if stops[i] == stops[i+1]:
            errors.append(f"Titik {i+1} dan {i+2} tidak boleh sama: **{stops[i]}**")

    if errors:
        for e in errors:
            st.warning(f"⚠️ {e}")
        st.session_state.last_result = None
    else:
        with st.spinner("Menghitung rute terpendek..."):
            all_segments = []
            total_distance = 0
            failed = False

            for i in range(len(stops) - 1):
                seg_start = stops[i]
                seg_end   = stops[i + 1]
                path, dist = dijkstra(seg_start, seg_end)

                if path is None:
                    st.error(f"❌ Tidak ada rute: **{seg_start}** → **{seg_end}**")
                    failed = True
                    break

                all_segments.append({
                    "path"     : path,
                    "distance" : dist,
                    "from"     : seg_start,
                    "to"       : seg_end,
                })
                total_distance += dist

        if not failed:
            st.session_state.last_result = {
                "segments"       : all_segments,
                "total_distance" : total_distance,
                "stops"          : stops[:],
            }


# -----------------------------------------------------------
# TAMPILAN HASIL
# -----------------------------------------------------------

result = st.session_state.last_result

col_graph, col_info = st.columns([2.5, 1], gap="large")

with col_graph:
    if result:
        segments_paths = [seg["path"] for seg in result["segments"]]
        # Judul: rangkum rute
        title_nodes = " → ".join(result["stops"])
        fig = draw_graph(
            segments=segments_paths,
            title=f"Rute: {title_nodes}",
        )
    else:
        fig = draw_graph(title="Kota Syntara — Jaringan Distribusi")

    st.pyplot(fig, use_container_width=True)

with col_info:
    if result:
        segs         = result["segments"]
        total_dist   = result["total_distance"]
        stops        = result["stops"]

        # --- Total ringkasan ---
        st.markdown('<div class="result-card">', unsafe_allow_html=True)
        st.markdown(
            f'<div class="distance-label">Total Jarak Keseluruhan</div>'
            f'<div class="distance-display">{total_dist} km</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            f'<br><b>{len(segs)} segmen</b> · <b>{len(stops)} titik</b>',
            unsafe_allow_html=True,
        )
        st.markdown('</div>', unsafe_allow_html=True)

        # --- Detail tiap segmen ---
        st.markdown("**Rincian Per Segmen**")

        from core.graph import GRAPH as _GRAPH

        for seg_idx, seg in enumerate(segs):
            color = SEGMENT_COLORS_HEX[seg_idx % len(SEGMENT_COLORS_HEX)]
            path = seg["path"]
            dist = seg["distance"]

            st.markdown(
                f'<div class="segment-card">'
                f'<div style="color:{color}; font-weight:700; font-size:0.9rem; margin-bottom:6px;">'
                f'Segmen {seg_idx+1}: {seg["from"]} → {seg["to"]}'
                f'</div>'
                f'<div style="color:#7F8C9A; font-size:0.82rem; margin-bottom:8px;">'
                f'Jarak: <b style="color:{color}">{dist} km</b></div>',
                unsafe_allow_html=True,
            )

            # Step per segmen
            steps = get_step_by_step(path)
            for i, step in enumerate(steps):
                fr = step["from"]
                to = step["to"]
                seg_d = _GRAPH[fr].get(to, _GRAPH.get(to, {}).get(fr, "?"))
                st.markdown(
                    f'<div style="background:#0F1923; border-radius:4px; padding:4px 8px; '
                    f'margin-bottom:3px; font-size:0.82rem; color:#C8D6E5;">'
                    f'{i+1}. {fr} <span style="color:{color}">→</span> {to} '
                    f'<span style="color:#7F8C9A">({seg_d} km)</span></div>',
                    unsafe_allow_html=True,
                )

            st.markdown('</div>', unsafe_allow_html=True)

    else:
        st.markdown('<div class="result-card">', unsafe_allow_html=True)
        st.markdown(
            "**Tambahkan titik tujuan** di panel kiri (tombol ➕ Tambah Titik), "
            "lalu klik **Hitung Rute Terpendek**.",
        )
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown("**Node dalam Jaringan**")
        for node, ntype in NODE_TYPES.items():
            label = {"depot": "Gudang Pusat", "hub": "Hub Transit", "zone": "Drop Point"}[ntype]
            st.markdown(
                f'<div class="step-item">⬡ {node} &nbsp;<span class="badge-{ntype}">{label}</span></div>',
                unsafe_allow_html=True,
            )


# -----------------------------------------------------------
# FOOTER
# -----------------------------------------------------------

st.divider()
st.markdown(
    '<div style="text-align:center; color:#3D5166; font-size:0.78rem;">'
    'DSS Rute Pengiriman Paket · Kota Syntara · Algoritma Dijkstra · Multi-Tujuan'
    '</div>',
    unsafe_allow_html=True,
)
